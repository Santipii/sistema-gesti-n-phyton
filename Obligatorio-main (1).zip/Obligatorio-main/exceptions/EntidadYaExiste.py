class EntidadYaExiste(Exception):
    pass